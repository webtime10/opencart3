<?php
// *	@copyright		Pavel Kravchenko; https://opencartforum.com/profile/711752-paulkravchenko/

// Heading
$_['heading_title'] = 'Pay with Amazon';

//Text
$_['text_module'] = 'Модули';
$_['text_success'] = 'Налаштування змінені';
$_['text_content_top'] = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left'] = 'Column Left';
$_['text_column_right'] = 'Column Right';
$_['text_pwa_button'] = 'Pay with Amazon';
$_['text_pay_button'] = 'Pay';
$_['text_a_button'] = 'A';
$_['text_gold_button'] = 'Gold';
$_['text_darkgray_button'] = 'Dark Gray';
$_['text_lightgray_button'] = 'Light Gray';
$_['text_small_button'] = 'Small';
$_['text_medium_button'] = 'Medium';
$_['text_large_button'] = 'Large';
$_['text_x_large_button'] = 'X-Large';

//Entry
$_['entry_button_type'] = 'Button Type';
$_['entry_button_colour'] = 'Button Colour';
$_['entry_button_size'] = 'Button Size';
$_['entry_layout'] = 'Layout';
$_['entry_position'] = 'Расположение';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

//Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін';