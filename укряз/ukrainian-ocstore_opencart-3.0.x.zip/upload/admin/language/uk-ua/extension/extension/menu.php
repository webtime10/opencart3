<?php
// *	@copyright		Pavel Kravchenko; https://opencartforum.com/profile/711752-paulkravchenko/

// Heading
$_['heading_title']    = 'Меню';

// Text
$_['text_success']     = 'Налаштування змінені';
$_['text_list']        = 'Список меню';

// Column
$_['column_name']      = 'Назва';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'У вас недостатньо прав для внесення змін';