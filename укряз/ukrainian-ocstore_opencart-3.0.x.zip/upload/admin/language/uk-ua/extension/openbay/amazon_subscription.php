<?php
// *	@copyright		Pavel Kravchenko; https://opencartforum.com/profile/711752-paulkravchenko/

// Heading
$_['heading_title']        				= 'Subscription';
$_['text_openbay']						= 'OpenBay Pro';
$_['text_amazon']						= 'Amazon EU';

// Text
$_['text_current_plan']             	= 'Current plan';
$_['text_register_invite']          	= 'Don’t have your API details yet?';
$_['text_available_plans']          	= 'Available plans';
$_['text_listings_remaining']       	= 'Listings remaining';
$_['text_listings_reserved']        	= 'Products being processed';
$_['text_account_status']           	= 'Account status';
$_['text_merchantid']               	= 'Merchant ID';
$_['text_change_merchantid']        	= 'Change';
$_['text_allowed']                  	= 'Allowed';
$_['text_not_allowed']              	= 'Not Allowed';
$_['text_price']              			= 'Цена';
$_['text_name']              			= 'Name';
$_['text_description']              	= 'Опис';
$_['text_order_frequency']          	= 'Order import frequency';
$_['text_bulk_listing']             	= 'Bulk Listing';
$_['text_product_listings']         	= 'Listings per month';

// Columns
$_['column_name']                     	= 'Name';
$_['column_description']              	= 'Опис';
$_['column_order_frequency']          	= 'Order import frequency';
$_['column_bulk_listing']             	= 'Bulk Listing';
$_['column_product_listings']         	= 'Listings per month';
$_['column_price']                    	= 'Цена';

// Buttons
$_['button_change_plan']              	= 'Change plan';
$_['button_register']                 	= 'Регистрация';