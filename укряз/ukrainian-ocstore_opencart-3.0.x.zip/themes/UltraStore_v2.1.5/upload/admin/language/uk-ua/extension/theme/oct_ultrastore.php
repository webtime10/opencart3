<?php
// Heading
$_['heading_title'] = '<font color="#45a4f4">UltraStore OCTemplates - налаштування шаблону</font>';