<?php
// Button
$_['add_question'] 				= 'Надіслати';

// Text
$_['entry_question']   			= 'Запитати:';
$_['text_write_a_question']   	= 'Написати запитання';
$_['text_answer_admin']   		= 'Відповідь представника:';
$_['text_no_question']   		= 'Немає запитань про цей товар.';
$_['tab_question_answer']       = 'Питання - відповідь (%s)';
$_['text_note_html']   			= '<span style="color:#a94442;">Увага</span>: HTML не підтримується! Використовуйте звичайний текст!';
$_['subject']   				= 'Запитання про товар';
$_['text_success_send']   		= 'Ваш запит надіслано';
$_['text_dateadded']			= 'Дата';
$_['text_buyer']				= 'Дані';
$_['text_name_fields']			= 'ПІБ';
$_['text_telephone_field']		= 'Телефон';
$_['text_comment_field']		= 'Запитання';
$_['text_email_field']			= 'Email';

// Error
$_['error_email_field']     	= 'Поле Email має бути заповнене';
$_['error_name_field']     		= 'Поле Ім’я має містити від 1 до 32';
$_['error_telephone_field']     = 'Телефон вказаний невірно';
$_['error_comment_field']       = 'Коментар має містити від 3 до 350 символів';
