<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>setka � Plum Store UI kit</title>
  <link rel="stylesheet" href="css/setka.css?v=z210">
</head>
<body class="theme-plum">
<?php include __DIR__ . '/partials/icons.php'; ?>
<?php include __DIR__ . '/partials/header.php'; ?>
<?php include __DIR__ . '/partials/hero.php'; ?>
<?php include __DIR__ . '/partials/cards.php'; ?>
<?php include __DIR__ . '/partials/controls.php'; ?>
<?php include __DIR__ . '/partials/footer.php'; ?>
<script src="js/theme.js?v=z210"></script>
</body>
</html>
